from django.apps import AppConfig


class MathematicsConfig(AppConfig):
    name = 'mathematics'
