from django.apps import AppConfig


class GreetingsConfig(AppConfig):
    name = 'greetings'
